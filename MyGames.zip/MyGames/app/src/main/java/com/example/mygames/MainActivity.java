package com.example.mygames;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnJogoDaVelha, btnPuzzle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnJogoDaVelha = findViewById(R.id.btnJogoDaVelha);
        btnPuzzle = findViewById(R.id.btnPuzzle);

        btnJogoDaVelha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVelha();
            }
        });
        btnPuzzle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPuzzle();
            }
        });
    }
    private void abrirVelha() {
        Intent janela = new Intent(this, JogoVelha.class);
        startActivity(janela);
    }
    private void abrirPuzzle() {
        Intent janelad = new Intent(this, Puzzle.class);
        startActivity(janelad);
    }
}

